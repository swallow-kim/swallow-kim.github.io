# Ready-for-repo package

This directory contains a proposed complete replacement for Mobile Antenna Design Notes Chapters 1-4.

## Contents

- `_notes/`: revised Chapter 1-4 Markdown
- `figures/`: final PNG/SVG assets with repository-ready names
- `scripts/figures/generate_mobile_antenna_ch1_4.py`: reproducible figure generator
- `scripts/figures/data/fig4_bandwidth.csv`: numerical values from dissertation Tables 2.5 and 2.6
- `scripts/figures/source/thesis_figures/`: extracted original simulation panels used for actual-data composites

## Generate figures

From the repository root:

```bash
python scripts/figures/generate_mobile_antenna_ch1_4.py
```

Required Python packages:

```text
numpy
matplotlib
Pillow
```

Conceptual figures are regenerated as vector SVG plus PNG. Actual CMA and surface-current figures preserve the original dissertation simulation data and are exported as PNG composites.

## Apply to the review branch

From the extracted package root:

```bash
./apply_to_repo.sh /path/to/swallow-kim.github.io
```

The target checkout must already be on `review/mobile-antenna-ch1-4`.
