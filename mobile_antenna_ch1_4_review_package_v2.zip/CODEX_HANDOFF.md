# Codex Handoff: Mobile Antenna Design Notes Chapters 1-4

Repository: `swallow-kim/swallow-kim.github.io`

This handoff contains a complete proposed replacement package under `ready_for_repo/`.

## 0. Scope and guardrails

Files in scope:

- `_notes/01-why-mobile-antenna-design-is-hard.md`
- `_notes/02-the-ground-is-not-just-ground.md`
- `_notes/03-ground-and-chassis-mode.md`
- `_notes/04-j-and-m-controlling-the-coupling-mechanism.md`
- chapter 1-4 figure assets under `figures/`
- reproducibility files under `scripts/figures/`

Do not modify chapters 5-9, layouts, SCSS, design tokens, or QA contracts unless validation proves a change is required.

The repository owner has authorized committing and pushing these scoped changes to `review/mobile-antenna-ch1-4`. Do not merge to `main` and do not open a PR unless separately requested.

Follow `AGENTS.md` and `DESIGN.md`.


## Working branch

Use the existing remote branch:

```text
review/mobile-antenna-ch1-4
```

Start with:

```bash
git fetch origin
git switch review/mobile-antenna-ch1-4
git pull --ff-only origin review/mobile-antenna-ch1-4
```

## 1. Technical objectives

The final chapter flow must be:

1. electrical-size and handset-integration constraints;
2. natural characteristic modes of the finite chassis;
3. feed-dependent modal excitation using standard terminology;
4. current-distribution control by geometry/reactive loading, supported by actual simulation and -6 dB bandwidth data.

The replacement removes nonstandard teaching terms such as:

- J-type excitation
- M-type excitation
- J-dominant / M-dominant source

Use instead:

- theory of characteristic modes (TCM)
- characteristic mode analysis (CMA)
- modal excitation coefficient (MEC)
- modal weighting coefficient (MWC), or modal expansion coefficient where appropriate
- capacitive coupling element (CCE)
- inductive coupling element (ICE)
- monopole-like / loop-like current distribution
- equivalent magnetic surface current only for a slot or aperture representation

## 2. Copy the revised Markdown

Replace these four files with the versions in this package:

```text
ready_for_repo/_notes/01-why-mobile-antenna-design-is-hard.md
ready_for_repo/_notes/02-the-ground-is-not-just-ground.md
ready_for_repo/_notes/03-ground-and-chassis-mode.md
ready_for_repo/_notes/04-j-and-m-controlling-the-coupling-mechanism.md
```

Keep the existing Chapter 4 permalink for backward compatibility even though the title no longer uses “J and M.”

Do not restore removed repetitive paragraphs or blockquotes.

## 3. Copy the revised figures

Copy all files from:

```text
ready_for_repo/figures/
```

to repository `figures/`, overwriting files with the same name.

Final referenced assets:

```text
fig1_1.png
fig1_1-720w.webp
fig1_1-1200w.webp
fig1_2.png
fig1_2.svg
fig1_3.png
fig1_3.svg
fig2_1.png
fig2_1.svg
fig2_2.png
fig3_1.png
fig3_1.svg
fig4_1.png
fig4_1.svg
fig4_2.png
fig4_3.png
fig4_3.svg
```

### Meaning of the new figure numbering

- `fig2_1`: simplified long-axis mode profile
- `fig2_2`: actual thesis CMA composite
- `fig3_1`: CCE/ICE placement
- `fig4_1`: reproduced loaded-antenna geometry
- `fig4_2`: actual thesis surface-current distributions
- `fig4_3`: -6 dB bandwidth replot

## 4. Add reproducibility files

Copy:

```text
ready_for_repo/scripts/figures/generate_mobile_antenna_ch1_4.py
ready_for_repo/scripts/figures/data/fig4_bandwidth.csv
ready_for_repo/scripts/figures/source/thesis_figures/*
```

The script writes directly to repository `figures/` and uses only the checked-in CSV and source crops.

Recommended environment:

```bash
python -m pip install numpy matplotlib pillow
python scripts/figures/generate_mobile_antenna_ch1_4.py
```

Do not replace the checked-in actual CMA/current images with synthetic heatmaps.

## 5. Delete obsolete unreferenced figures

After replacing the notes and running `rg`, delete only assets that are no longer referenced anywhere:

Expected obsolete files:

```text
fig2_2.svg       # old conceptual asset; new fig2_2 is actual PNG only
fig3_2.png
fig3_2.svg
fig3_3.png
fig3_3.svg
fig4_2.svg       # old conceptual asset; new fig4_2 is actual PNG only
fig4_4.png
fig4_4.svg
```

Before deletion, verify with:

```bash
rg -n 'fig2_2\.svg|fig3_2|fig3_3|fig4_2\.svg|fig4_4' . \
  --glob '!_site/**' --glob '!_site_qa/**'
```

Do not delete existing `fig1_1` assets.

## 6. Required technical checks

Verify all of the following:

- TCM means “theory of characteristic modes.”
- CMA means “characteristic mode analysis.”
- Modal significance is not described as a feed-coupling metric.
- Feed dependence is described with MEC/MWC language.
- A conducting loop carries ordinary conduction current.
- Equivalent magnetic surface current is used only for slots/apertures.
- “modal voltage maximum” has been replaced by charge/electric-field maximum.
- Chapter 4 bandwidth is explicitly `-6 dB impedance bandwidth`.
- Measured bandwidth is not presented as radiation efficiency.
- The difference between measured and lossless-simulated bandwidth is attributed to additional losses.
- The 150 mm x 80 mm conceptual plate is not presented as the same geometry as the 30 mm x 150 mm CMA example.
- Thesis Fig. 2.12 geometry is 50 mm x 115 mm ground with 5 mm x 25 mm clearance.

## 7. Required style checks

The revised text intentionally uses simple English. Do not “improve” it into polished marketing copy.

Avoid adding:

- “This is one of the most important ideas...”
- “The practical intuition is simple...”
- repeated rhetorical questions
- repeated “useful,” “powerful,” “fundamental,” or “key” claims
- new teaching categories not found in antenna literature

The desired voice is a Korean RF engineer writing clear technical notes in English.

## 8. Figure checks

For each figure:

- verify source and fallback paths exist;
- verify explicit `width` and `height` match the asset dimensions;
- verify alt text describes the actual image;
- verify conceptual figures are labelled conceptual;
- verify actual thesis figures are labelled as original simulation data;
- verify no fake solver-like heatmap was generated;
- verify dense labels are legible at the site's reading width and scroll correctly on mobile.

The thesis-derived source locations are:

- Figs. 2.2 and 2.3: dissertation printed p. 17 / PDF p. 32
- Fig. 2.12: printed p. 33 / PDF p. 48
- Table 2.5 and Fig. 2.13: printed p. 34 / PDF p. 49
- Table 2.6: printed p. 36 / PDF p. 51

## 9. Validation

Run exactly the repository checks documented in `AGENTS.md`:

```bash
bundle install
npm install
npm run doctor
npm run test:contract
bundle exec rake validate
```

Also run:

```bash
rg -n '\b(J-type|M-type|J-dominant|M-dominant|modal voltage)\b' _notes/0[1-4]*.md
rg -n 'fig[1-4]_[0-9]' _notes/0[1-4]*.md
```

Expected result of the terminology check: no matches, except historical text explicitly quoted for review (there should be none in production notes).

Check image dimensions programmatically against the HTML attributes. Update attributes only if regeneration changed the pixel size.

## 10. Final report

Report:

1. exact files replaced;
2. exact assets added/deleted;
3. any deviation from this package and why;
4. validation command results;
5. any figure whose provenance could not be verified;
6. git status and diff summary.

Do not publish changes without separate authorization.
