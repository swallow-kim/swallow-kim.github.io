#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<'EOF'
Usage: apply_to_repo.sh [REPO_PATH]

Overlay the reviewed Mobile Antenna Design Notes Chapter 1-4 package onto a
local checkout of swallow-kim/swallow-kim.github.io.

Run this only on branch review/mobile-antenna-ch1-4. The script copies the
reviewed Markdown, figures, and reproducibility files, then removes obsolete
figure assets only when they are no longer referenced.
EOF
}

if [[ ${1:-} == "-h" || ${1:-} == "--help" ]]; then
  usage
  exit 0
fi

REPO=$(cd "${1:-.}" && pwd)
SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
SRC="$SCRIPT_DIR/ready_for_repo"
EXPECTED_BRANCH="review/mobile-antenna-ch1-4"

if [[ ! -d "$REPO/.git" ]]; then
  echo "ERROR: $REPO is not a Git worktree." >&2
  exit 2
fi

branch=$(git -C "$REPO" branch --show-current)
if [[ "$branch" != "$EXPECTED_BRANCH" ]]; then
  echo "ERROR: current branch is '$branch'; expected '$EXPECTED_BRANCH'." >&2
  echo "Run: git fetch origin && git switch $EXPECTED_BRANCH" >&2
  exit 3
fi

# Protect against overwriting unrelated local edits in the files this package owns.
mapfile -t owned_paths <<'EOF'
_notes/01-why-mobile-antenna-design-is-hard.md
_notes/02-the-ground-is-not-just-ground.md
_notes/03-ground-and-chassis-mode.md
_notes/04-j-and-m-controlling-the-coupling-mechanism.md
figures/fig1_2.png
figures/fig1_2.svg
figures/fig1_3.png
figures/fig1_3.svg
figures/fig2_1.png
figures/fig2_1.svg
figures/fig2_2.png
figures/fig3_1.png
figures/fig3_1.svg
figures/fig4_1.png
figures/fig4_1.svg
figures/fig4_2.png
figures/fig4_3.png
figures/fig4_3.svg
scripts/figures/SOURCE_PROVENANCE.md
scripts/figures/data/fig4_bandwidth.csv
scripts/figures/generate_mobile_antenna_ch1_4.py
scripts/figures/source/thesis_figures/fig2_13_case1_loop.jpg
scripts/figures/source/thesis_figures/fig2_13_case5_monopole.jpg
scripts/figures/source/thesis_figures/fig2_2_modes_a_b.jpg
scripts/figures/source/thesis_figures/fig2_2_modes_b_c.jpg
scripts/figures/source/thesis_figures/fig2_3_modal_significance.jpg
EOF

conflicts=()
for p in "${owned_paths[@]}"; do
  if ! git -C "$REPO" diff --quiet -- "$p" || ! git -C "$REPO" diff --cached --quiet -- "$p"; then
    conflicts+=("$p")
  fi
done
if ((${#conflicts[@]})); then
  printf 'ERROR: package-owned paths already have local changes:\n' >&2
  printf '  %s\n' "${conflicts[@]}" >&2
  echo "Commit/stash/review them before applying this package." >&2
  exit 4
fi

mkdir -p \
  "$REPO/_notes" \
  "$REPO/figures" \
  "$REPO/scripts/figures/data" \
  "$REPO/scripts/figures/source/thesis_figures"

cp -f "$SRC"/_notes/*.md "$REPO/_notes/"
cp -f "$SRC"/figures/* "$REPO/figures/"
cp -f "$SRC"/scripts/figures/generate_mobile_antenna_ch1_4.py "$REPO/scripts/figures/"
cp -f "$SRC"/scripts/figures/SOURCE_PROVENANCE.md "$REPO/scripts/figures/"
cp -f "$SRC"/scripts/figures/data/fig4_bandwidth.csv "$REPO/scripts/figures/data/"
cp -f "$SRC"/scripts/figures/source/thesis_figures/* \
  "$REPO/scripts/figures/source/thesis_figures/"

# Remove only known obsolete assets, and only if no source file still references them.
obsolete=(
  figures/fig2_2.svg
  figures/fig3_2.png
  figures/fig3_2.svg
  figures/fig3_3.png
  figures/fig3_3.svg
  figures/fig4_2.svg
  figures/fig4_4.png
  figures/fig4_4.svg
)

for p in "${obsolete[@]}"; do
  base=$(basename "$p")
  refs=$(git -C "$REPO" grep -n -F "$base" -- \
    ':!_site/**' ':!_site_qa/**' ':!*.lock' 2>/dev/null || true)
  # Ignore a reference from the file itself if Git happens to index text SVG content.
  refs=$(printf '%s\n' "$refs" | grep -v -F "$p:" || true)
  if [[ -z "$refs" ]]; then
    rm -f "$REPO/$p"
  else
    echo "KEEP $p: still referenced:" >&2
    printf '%s\n' "$refs" >&2
  fi
done

echo
echo "Package applied to: $REPO"
echo "Current branch:    $branch"
echo
echo "Review the changes with:"
echo "  git status --short"
echo "  git diff --stat"
echo "  git diff -- _notes/01-why-mobile-antenna-design-is-hard.md"
echo
echo "Then follow CODEX_HANDOFF.md for generation and validation."
