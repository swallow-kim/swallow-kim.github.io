# Mobile Antenna Design Notes Ch. 1-4 기술 검토

검토 대상: `swallow-kim/swallow-kim.github.io`의 `_notes/01`-`04` (main branch)

검토 기준:

- 이전에 합의한 thesis-informed master plan
- 저자의 박사학위논문 *Performance Enhancement of Multiband Ground Radiation Antenna Using Multi-Resonant Loops* (Hanyang University, 2020)
- characteristic-mode 문헌과 상용 solver에서 실제 쓰는 용어
- 개인 기술 블로그에 적합한 간결한 영어 문체
- AI-generated infographic보다 논문 그림에 가까운 시각 체계

## 1. 결론

현재 버전은 master plan의 **구조와 문단 추가는 대부분 구현**했다. 그러나 최종 목표였던 “conceptual explanation -> actual CMA -> actual current distribution -> measurement” 흐름은 아직 완성되지 않았다.

- 기계적인 구현률: 약 **75-80%**
- 기술 편집과 evidence까지 포함한 완성도: 약 **60-65%**

가장 큰 문제는 다음 세 가지다.

1. `J-type / M-type excitation`, `J-dominant / M-dominant`가 표준 학술 용어처럼 사용된다. 이 표현은 현재 antenna/TCM 문헌의 통상 용어로 확인되지 않았다.
2. 실제 thesis evidence인 CMA 결과와 surface-current 결과가 빠져 있고, 대신 개념도가 과도하게 많다.
3. measured impedance bandwidth가 radiation performance의 직접 증거처럼 읽힐 수 있다. Thesis의 bandwidth는 **-6 dB impedance bandwidth**이며, 측정값이 lossless simulation보다 넓어진 주된 이유는 additional loss이다.

따라서 기존 문장을 부분 수정하는 방식보다, 제공한 revised Ch. 1-4 파일로 교체하고 figure set을 줄이는 편이 안전하다.

## 2. Master plan 구현 상태

| Chapter | 계획 | 현재 상태 | 판정 |
|---|---|---|---|
| Ch. 1 | small-antenna limit, finite chassis, placement, Fig. 1-2/1-3 | 본문과 Fig. 1-2 반영, Fig. 1-3 미반영 | 본문 완료, figure 미완료 |
| Ch. 2 | natural mode, resonance vs excitation, actual CMA | 본문과 개념도 반영, actual CMA 미반영 | 핵심 evidence 누락 |
| Ch. 3 | source-location/orientation, J/M terminology correction | vector overlap은 반영됐으나 `J-type/M-type`이 남음, 개념도 3개 삽입 | 부분 실패: master plan 자체의 용어를 재검토해야 함 |
| Ch. 4 | loading -> current redistribution -> actual simulation/measurement | practical example와 bandwidth plot 반영, actual current plot 누락 | 핵심 evidence 누락, bandwidth 해석 보완 필요 |

### Chapter 1

좋은 점:

- small-antenna Q와 bandwidth limitation이 짧게 들어갔다.
- high Q를 efficiency와 직접 등치하지 않았다.
- low/high frequency를 단순 이분법으로 나누지 않았다.
- S11과 radiation efficiency를 구분했다.

남은 문제:

- `product-level electromagnetic system`, `useful mode`, `important mental model`이 반복되어 AI-generated training material처럼 들린다.
- “the antenna element does not radiate efficiently by itself”는 coupled structure에서 element와 chassis의 radiated power를 분리 가능한 것처럼 읽힌다.
- Fig. 1-3이 아직 TODO다.

### Chapter 2

좋은 점:

- charge/fringing-E와 current maximum을 분리했다.
- resonant mode가 항상 strongly excited되는 것은 아니라는 설명이 들어갔다.

남은 문제:

- `CMA or TCM`이라고 쓰면 안 된다. 표준 구분은 다음과 같다.
  - **theory of characteristic modes (TCM)**
  - **characteristic mode analysis (CMA)**
- `radiation potential`, `excitation difficulty`는 정식 CMA output quantity가 아니다.
- 실제 characteristic currents와 modal-significance 결과가 없다.

권장 output terminology:

- eigenvalue
- characteristic angle
- modal significance
- characteristic current / characteristic far field
- modal excitation coefficient (MEC)
- modal weighting coefficient (MWC), 또는 solver에 따라 modal expansion coefficient

### Chapter 3

좋은 점:

- coupling이 scalar field magnitude가 아니라 spatial/vector overlap에 의존한다고 수정했다.
- metal loop의 conduction current와 slot의 equivalent magnetic current를 구분하려는 문장이 들어갔다.

문제:

- `J-type / M-type excitation`은 이 글에서 새로 만든 teaching shorthand에 가깝다. 표준 용어처럼 제목과 핵심 메시지에 쓰지 않는 편이 좋다.
- `source-mode coupling`보다 characteristic-mode 문헌에서는 `modal excitation`, `modal excitation coefficient`, `feed coupling to a characteristic mode`가 더 자연스럽다.
- electric/magnetic response를 하나의 scalar ratio처럼 설명하는 문장이 많다.
- Fig. 3-1/3-2/3-3은 대부분 같은 sinusoidal chassis-mode intuition을 반복한다.

대체 권장 용어:

- **capacitive coupling element (CCE)**
- **inductive coupling element (ICE)**
- capacitive excitation / inductive excitation
- modal excitation coefficient
- feed position and orientation
- monopole-like / loop-like current distribution
- equivalent magnetic surface current: slot/aperture에만 사용

### Chapter 4

좋은 점:

- reactive loading을 단순 resonance tuning이 아니라 current-distribution control로 설명했다.
- monopole-like가 항상 더 낫다는 결론을 피했다.

중요 수정:

- Chapter title과 topics에서 `J and M`, `magnetic current`를 제거한다.
- current example의 bandwidth는 모두 **-6 dB impedance bandwidth**라고 명시한다.
- lossless simulation과 measurement를 같은 성능 지표처럼 해석하지 않는다.
- thesis는 measurement와 simulation의 차이를 extra loss로 설명한다. Loss는 input match를 넓힐 수 있지만 radiation efficiency를 떨어뜨릴 수 있다.
- current version의 “the thesis PDF and exact page or table locator are not present in this repository”는 내부 agent note이므로 공개 caption에서 삭제한다.

정확한 thesis locator:

- Figs. 2.2 and 2.3: printed p. 17, PDF p. 32
- Fig. 2.12: printed p. 33, PDF p. 48
- Table 2.5 and Fig. 2.13: printed p. 34, PDF p. 49
- Table 2.6: printed p. 36, PDF p. 51

## 3. 기술적으로 수정할 문장 유형

### A. 과도한 일반화

현재 취지:

> The ground or chassis is the largest and most important radiating body.

권장:

> For many low-band handset designs, a large fraction of the radiating current flows on the PCB ground, frame, or other large conductors.

이유: frequency, antenna topology, frame connectivity, product geometry에 따라 달라진다.

### B. 물리적으로 분리하기 어려운 표현

현재 취지:

> The antenna element does not radiate efficiently by itself.

권장:

> It is misleading to analyze the small element independently of the chassis because the driven current extends over the complete conducting structure.

### C. modal voltage

피할 표현:

- modal voltage maximum on a PEC plate
- voltage region of the ground mode

권장:

- surface-charge maximum
- modal electric-field maximum
- current minimum

### D. loop와 magnetic current

권장 구분:

- conducting loop: ordinary conduction current, magnetic dipole moment, inductive coupling
- slot/aperture: equivalent magnetic surface current representation

### E. bandwidth와 efficiency

반드시 구분:

- impedance bandwidth
- radiation efficiency
- total efficiency
- lossless radiation resistance

Measured bandwidth가 넓다고 radiation performance가 좋아졌다고 바로 결론내리면 안 된다.

## 4. AI-generated 느낌을 줄이는 문체 원칙

현재 글은 기술적 방향은 좋지만, 다음 패턴이 반복된다.

- `This is one of the most important...`
- `The practical intuition is simple...`
- `This explains...`
- `This is where ... becomes interesting.`
- 질문 blockquote를 연속으로 배치
- 같은 결론을 section, callout, key message에서 세 번 반복
- `useful`, `important`, `basic idea`, `design logic`, `practical meaning`의 과다 사용

권장 규칙:

1. 같은 결론은 한 번만 쓴다.
2. 한 section에 blockquote는 최대 한 개만 둔다.
3. 문장은 짧고 직접적으로 쓴다.
4. 논문처럼 과도하게 formal하게 쓰지 않는다.
5. 한국인 RF 엔지니어가 영어로 기록한 technical note처럼 간단한 동사를 쓴다.

예:

- 과한 문장: `This shift is powerful and gives us a more physical design process.`
- 권장: `CMA changes the order of the design work.`

- 과한 문장: `The practical intuition is simple: place the right kind of source where the corresponding field is strong.`
- 권장: `Choose the feed position and orientation from the target mode's local fields.`

- 과한 문장: `The topology is only the starting point.`를 여러 번 반복
- 권장: Chapter 4 key message에서 한 번만 사용

제공한 revised Markdown은 원문 분량을 약 20-30% 줄이고 이 원칙을 반영했다.

## 5. Figure audit와 최종 권장 세트

현재 conceptual figure가 너무 많고, 일부는 같은 sinusoidal mode를 반복한다. 논문형 기술 노트에는 다음 9개면 충분하다.

| Figure | 결정 | 구현 방식 |
|---|---|---|
| Fig. 1-1 | 유지 | 기존 handset overview |
| Fig. 1-2 | 재생성 | canonical single-mode Chu reference, clean vector plot |
| Fig. 1-3 | 신규 | same chassis mode, source location만 이동 |
| Fig. 2-1 | 재생성 | one conceptual long-axis mode profile |
| Fig. 2-2 | thesis data 사용 | actual characteristic currents + modal significance |
| Fig. 3-1 | 재생성 | CCE vs ICE, standard terminology |
| Fig. 4-1 | reproduce | thesis Fig. 2.12 geometry as clean line drawing |
| Fig. 4-2 | thesis data 사용 | actual surface-current distributions from Fig. 2.13 |
| Fig. 4-3 | replot | Tables 2.5/2.6, -6 dB bandwidth + loss caution |

삭제할 현재 figure:

- generic circuit-ground vs RF-ground cartoon
- 반복되는 Ch. 3 field/source/proxy 3종 세트 중 2개 이상
- generic J-like/M-like/hybrid cartoon
- generic “inductive/capacitive design knobs” cartoon

### AI image generation 사용 여부

이 chapter set에는 AI image generation을 권하지 않는다.

- analytical curve: Python/matplotlib
- conceptual field/current: vector schematic
- CMA/current magnitude: original simulation data 또는 thesis figure
- measured/simulated values: exact data replot

AI-generated field map은 실제 solver output처럼 보이면서 물리적으로 틀릴 위험이 크다.

## 6. 직접 준비한 교체안

`ready_for_repo/`에는 다음이 들어 있다.

- `_notes/01`-`04`: 전체 교체 가능한 revised Markdown
- `figures/`: 최종 figure names로 정리한 PNG/SVG
- `scripts/figures/generate_mobile_antenna_ch1_4.py`: 재생성 스크립트
- `scripts/figures/data/fig4_bandwidth.csv`: thesis numerical data
- `scripts/figures/source/thesis_figures/`: actual thesis simulation crops

그림 생성 원칙:

- conceptual data와 actual simulation data를 caption에서 구분
- original simulation colors/amplitudes는 임의 생성하지 않음
- actual thesis figure에는 source locator 명시
- site의 paper/ink/signal-blue 체계에 맞춤
- 불필요한 infographic box, gradient, shadow 제거

## 7. Publication/attribution note

Thesis PDF에는 CC BY-NC-ND 2.0 Korea 표시가 있다. 저자 본인의 학위논문이라도, 동일 figure가 별도 journal/conference paper에 실렸고 출판권이 이전되었다면 그 publication의 reuse 조건도 확인하는 것이 안전하다.

가장 안전한 순서:

1. original solver/raw data에서 다시 export
2. thesis numerical data를 새 plot으로 replot
3. 원본 thesis figure를 사용할 때 정확한 figure number와 dissertation citation 표시

