# Codex bootstrap prompt

Use this after attaching or extracting `mobile_antenna_ch1_4_review_package.zip`
next to the local repository checkout.

```text
Work in repository swallow-kim/swallow-kim.github.io.

1. Run `git fetch origin` and switch to `review/mobile-antenna-ch1-4`.
2. Read `AGENTS.md` and `DESIGN.md` first.
3. Extract the attached review package outside the repository if needed, then
   run its `apply_to_repo.sh <repo-path>` script.
4. Follow `CODEX_HANDOFF.md` exactly. Do not rewrite the reviewed prose into
   more polished or marketing-style English. Preserve the standard antenna
   terminology and thesis-data provenance.
5. Regenerate the figures once with
   `python scripts/figures/generate_mobile_antenna_ch1_4.py` and verify that
   generated files match the checked-in assets or explain any deterministic
   rendering difference.
6. Run the repository validation commands from `AGENTS.md`:
   `bundle install`, `npm install`, `npm run doctor`,
   `npm run test:contract`, and `bundle exec rake validate`.
7. Inspect the full diff. Do not modify Chapters 5-9, layouts, SCSS, or design
   tokens unless a validation failure proves it is necessary.
8. Commit only the reviewed Chapter 1-4 note, figure, and reproducibility paths
   on `review/mobile-antenna-ch1-4`, then push that branch. Do not merge to
   `main`. Do not open a PR unless I explicitly ask.
9. Report exact files added/modified/deleted, validation results, and any
   deviation from `CODEX_HANDOFF.md`.
```
